
export default class Event {
    constructor(){

    }
    
}