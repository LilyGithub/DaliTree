export default {
    NEED_PROMISE: {
        code: 'e00001',
        msg: '当type为async时，数据接口dataInterface必须返回一个Promise对象'
    }
}