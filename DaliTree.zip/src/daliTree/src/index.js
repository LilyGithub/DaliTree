import DaliTree from './dali-tree.ts';
import './skin/classic/base.less';
export {
    DaliTree
}